"""
Sentiment Analysis of Reviews — CODTECH project
Run: python sentiment_analysis.py

Looks for reviews.csv first; falls back to sample_reviews.csv.
Creates charts, metrics, and predictions in the outputs/ folder.
"""
from pathlib import Path
import re
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    precision_recall_fscore_support
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.utils.multiclass import unique_labels

warnings.filterwarnings("ignore", category=FutureWarning)
ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "outputs"
OUTPUT.mkdir(exist_ok=True)


def clean_text(value):
    """Basic text normalization while preserving useful words."""
    text = str(value).lower()
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"[^a-z0-9\s']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def find_column(df, candidates):
    lower_map = {c.strip().lower(): c for c in df.columns}
    for candidate in candidates:
        if candidate in lower_map:
            return lower_map[candidate]
    return None


def normalize_labels(df, label_col):
    """Normalize sentiment labels; map numeric ratings when named 'rating'."""
    values = df[label_col]
    if label_col.strip().lower() == "rating":
        ratings = pd.to_numeric(values, errors="coerce")
        mapping = {1: "Negative", 2: "Negative", 3: "Neutral",
                   4: "Positive", 5: "Positive"}
        return ratings.map(mapping)

    def normalize_one(v):
        s = str(v).strip().lower()
        mapping = {
            "positive": "Positive", "pos": "Positive", "good": "Positive",
            "negative": "Negative", "neg": "Negative", "bad": "Negative",
            "neutral": "Neutral", "mixed": "Neutral",
        }
        return mapping.get(s)
    return values.map(normalize_one)


def load_dataset():
    preferred = ROOT / "reviews.csv"
    sample = ROOT / "sample_reviews.csv"
    path = preferred if preferred.exists() else sample
    df = pd.read_csv(path)
    df.columns = [str(c).strip() for c in df.columns]
    text_col = find_column(df, ["review", "text", "review_text", "comment", "content"])
    label_col = find_column(df, ["sentiment", "label", "rating_label", "rating"])
    if text_col is None or label_col is None:
        raise ValueError(
            "Dataset needs a review text column (review/text/review_text/comment) "
            "and a label column (sentiment/label/rating_label/rating)."
        )
    df = df[[text_col, label_col]].rename(columns={text_col: "review", label_col: "sentiment"})
    df["review"] = df["review"].fillna("").astype(str).map(clean_text)
    df["sentiment"] = normalize_labels(df, "sentiment")
    df = df[(df["review"].str.len() > 0) & df["sentiment"].notna()].drop_duplicates()
    if df.empty:
        raise ValueError("No usable rows found. Check review text and sentiment labels.")
    print(f"Loaded {len(df)} labeled reviews from {path.name}")
    return df


def create_distribution_chart(df):
    order = ["Negative", "Neutral", "Positive"]
    counts = df["sentiment"].value_counts().reindex(order, fill_value=0)
    fig, ax = plt.subplots(figsize=(7, 5))
    bars = ax.bar(counts.index, counts.values)
    ax.bar_label(bars)
    ax.set_title("Distribution of Review Sentiments")
    ax.set_xlabel("Sentiment")
    ax.set_ylabel("Number of reviews")
    fig.tight_layout()
    fig.savefig(OUTPUT / "sentiment_distribution.png", dpi=160)
    plt.close(fig)


def build_and_evaluate(df):
    X = df["review"]
    y = df["sentiment"]
    counts = y.value_counts()
    if len(counts) < 2 or counts.min() < 2:
        print("Not enough labeled examples per class to train/evaluate. Add more labeled reviews.")
        return None

    # Small datasets need a test size large enough to represent all classes.
    test_size = max(0.25, len(counts) / len(df))
    if test_size >= 0.5:
        test_size = 0.4
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=y
    )

    model = Pipeline([
        ("tfidf", TfidfVectorizer(
            preprocessor=clean_text,
            ngram_range=(1, 2),
            max_features=5000,
            min_df=1,
            sublinear_tf=True,
        )),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)),
    ])
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, pred)
    report = classification_report(y_test, pred, zero_division=0)

    with open(OUTPUT / "model_metrics.txt", "w", encoding="utf-8") as f:
        f.write("Sentiment Analysis Model Evaluation\n")
        f.write("=" * 38 + "\n")
        f.write(f"Dataset rows: {len(df)}\n")
        f.write(f"Training rows: {len(X_train)}\n")
        f.write(f"Test rows: {len(X_test)}\n")
        f.write(f"Accuracy: {accuracy:.3f}\n\n")
        f.write("Classification report:\n")
        f.write(report)
    print(f"\nTest accuracy: {accuracy:.3f}")
    print("\nClassification report:\n" + report)

    labels = ["Negative", "Neutral", "Positive"]
    cm = confusion_matrix(y_test, pred, labels=labels)
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, interpolation="nearest")
    ax.set_title("Sentiment Classification Confusion Matrix")
    ax.set_xlabel("Predicted sentiment")
    ax.set_ylabel("Actual sentiment")
    ax.set_xticks(range(len(labels)), labels=labels, rotation=20)
    ax.set_yticks(range(len(labels)), labels=labels)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center")
    fig.tight_layout()
    fig.savefig(OUTPUT / "confusion_matrix.png", dpi=160)
    plt.close(fig)

    # Save predictions for the supplied custom review file if it exists.
    predict_path = ROOT / "sample_reviews_to_predict.csv"
    if predict_path.exists():
        custom = pd.read_csv(predict_path)
        col = find_column(custom, ["review", "text", "review_text", "comment", "content"])
        if col:
            custom["predicted_sentiment"] = model.predict(custom[col].fillna("").astype(str))
            if hasattr(model.named_steps["classifier"], "predict_proba"):
                probabilities = model.predict_proba(custom[col].fillna("").astype(str))
                custom["confidence"] = probabilities.max(axis=1).round(3)
            custom.to_csv(OUTPUT / "custom_review_predictions.csv", index=False)
            print(f"\nSaved custom predictions to {OUTPUT / 'custom_review_predictions.csv'}")

    # Save a compact summary for reporting.
    metrics = pd.DataFrame({
        "Metric": ["Number of reviews", "Number of sentiment classes", "Test accuracy"],
        "Value": [len(df), y.nunique(), round(accuracy, 3)],
    })
    metrics.to_csv(OUTPUT / "summary_statistics.csv", index=False)
    return model


def main():
    df = load_dataset()
    print("\nSample records:")
    print(df.head(5).to_string(index=False))
    print("\nSentiment counts:")
    print(df["sentiment"].value_counts().to_string())
    print("\nMissing values:")
    print(df.isna().sum().to_string())

    df.to_csv(OUTPUT / "cleaned_reviews.csv", index=False)
    create_distribution_chart(df)
    build_and_evaluate(df)
    print(f"\nFinished. Check output files in: {OUTPUT}")


if __name__ == "__main__":
    main()
