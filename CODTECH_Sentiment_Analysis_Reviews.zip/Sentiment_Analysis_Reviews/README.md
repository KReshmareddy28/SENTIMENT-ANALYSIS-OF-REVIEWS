# Sentiment Analysis of Reviews — CODTECH Project

This beginner-friendly Python project classifies written reviews as **Positive**, **Negative**, or **Neutral** using TF-IDF text features and a Logistic Regression model.

## Files
- `sentiment_analysis.py` — main program: loads data, cleans text, trains/evaluates a model, predicts custom reviews, and creates a chart.
- `sample_reviews.csv` — small sample dataset included for a quick demonstration.
- `requirements.txt` — dependencies.
- `CODTECH_Sentiment_Analysis_Report.md` — report template for internship documentation.
- `sample_reviews_to_predict.csv` — example reviews to classify after training.

## Run
1. Install Python 3.10 or newer.
2. Extract this folder and open it in VS Code.
3. In the terminal, run:
   ```bash
   pip install -r requirements.txt
   python sentiment_analysis.py
   ```
4. Generated files appear in `outputs/`.

## Use your own dataset
The program first checks for `reviews.csv`; if missing, it uses `sample_reviews.csv`.
Expected columns:
- Review text column: `review`, `text`, `review_text`, or `comment`
- Sentiment label column: `sentiment`, `label`, or `rating_label`
Labels may be Positive/Negative/Neutral, or common 1–5 star ratings if the column is named `rating`:
- 1–2 = Negative, 3 = Neutral, 4–5 = Positive

If your CODTECH instructions specify a particular dataset, use that dataset and adjust the column names if needed.

## Important
The included dataset is a small illustrative sample created for demonstration, not a real review corpus. Its scores should not be presented as production-quality results. For a stronger project, train and evaluate with a larger, properly sourced dataset.
